-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 23, 2011 at 03:56 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.5

-- SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `travel_ideas`
--

-- --------------------------------------------------------



CREATE TABLE IF NOT EXISTS `members` (
  `member_id` int(11) NOT NULL auto_increment,
  `member_name` varchar(20) NOT NULL UNIQUE,
  `email` varchar(50) NOT NULL UNIQUE,                  
  `member_password` varchar(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name`  varchar(50) NOT NULL,
  `comment_amount` int(5) default '0',
  PRIMARY KEY  (`member_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `members`
--
-- -------------------------- ------------------------------
CREATE TABLE IF NOT EXISTS `travel_ideas` (
  `travel_id` int(11) NOT NULL auto_increment,
  
  `title` varchar(250) NOT NULL UNIQUE,   
  `travel_ideas` text  NOT NULL,
  `tags` varchar(100) ,
  `start_date` text NOT NULL,
  `end_date` text NOT NULL,
  `destination` varchar(100) NOT NULL,
  `title_user` varchar(20), 		-- 链接 member 表
  `comment_id` int(11),             -- 链接 评论  表
  `founding_date` text ,
  PRIMARY KEY  (`travel_id`),
  FOREIGN KEY  (`title_user`) REFERENCES members(member_name),  -- 这里以后可能会有bug需要谨慎
  FOREIGN KEY  (`comment_id`) REFERENCES travel_comments(comment_id)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `travel_comments` (
  `comment_id` int(11) NOT NULL auto_increment,
  `comment_user` varchar(20), 
  `comments` text ,
  `title`  varchar(250),
  `comment_date` text NOT NULL,   
  PRIMARY KEY  (`comment_id`),
  FOREIGN KEY  (`comment_user`) REFERENCES members(member_name),
  FOREIGN KEY  (`title`) REFERENCES travel_ideas(title)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


-- 11/21/6:31



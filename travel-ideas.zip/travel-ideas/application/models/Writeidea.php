<?php
/*
class Application_Model_Writeidea
{
	protected $_name="travel_ideas";

}
*/
class Application_Model_Writeidea
{
    protected $travel_id;
    protected $travel_ideas;
    protected $title;
	protected $start_date;
	protected $end_date;
	protected $destination;
	protected $tags;
	protected $title_user;
	protected $comment_id;
	protected $founding_date;
	

	public function __construct(array $options = null)
    {
        if (is_array($options)) {
            $this->setOptions($options);
        }
    }
	
	public function __set($name, $value)
    {
        $method = 'set' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid member property');
        }
        $this->$method($value);
    }

	public function __get($name)
    {
        $method = 'get' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid Member property');
        }
        return $this->$method();
    }
	
	public function setOptions(array $options)
    {
        $methods = get_class_methods($this);
        foreach ($options as $key => $value) {
            $method = 'set' . ucfirst($key);
            if (in_array($method, $methods)) {
                $this->$method($value);
            }
        }
        return $this;
    }
	
	public function setTravelId($travelId)
    {
        $this->travel_id = (int) $travelId;
        return $this;
    }

    public function getTravelId()
    {
        return $this->travel_id;
    }
    
    public function setTravelIdeas($travelIdeas)
    {
        $this->travel_ideas = (string) $travelIdeas;
        return $this;
    }

    public function getTravelIdeas()
    {
        return $this->travel_ideas;
    }
    
    
    
	
	public function setTitle($title)   //maybe bugs
    {
        $this->title = (string) $title;
        return $this;
    }
 
    public function getTitle()     
    {
        return $this->title;      //maybe bugs
    }
	
	
	
	public function setStartDate($startDate)
    {
        $this->start_date = (String) $startDate;
        return $this;
    }

    public function getStartDate()
    {
        return $this->start_date;
    }
	
	public function setEndDate($endDate)
    {
        $this->end_date = (String) $endDate;
        return $this;
    }

    public function getEndDate()
    {
        return $this->end_date;
    }
	
	public function setDestination($destination)
    {
        $this->destination = (String) $destination;
        return $this;
    }

    public function getDestination()
    {
        return $this->destination;
    }
    
    
  
    public function setTags($tags)
    {
        $this->tags = (string) $tags;
        return $this;
    }

    public function getTags()
    {
        return $this->tags;
    }

    
    
   
    public function setTitleUser($titleUser)
    {
        $this->title_user = (String) $titleUser;
        return $this;
    }

    public function getTitleUser()
    {
        return $this->title_user;
    }
    
    
    
    public function setCommentId($commentId)
    {
        $this->comment_id = (int) $commentId;
        return $this;
    }

    public function getCommentId()
    {
        return $this->comment_id;
    }
    
    
    
    public function setFoundingDate($foundingDate)
    {
        $this->founding_date = (String) $foundingDate;
        return $this;
    }

    public function getFoundingDate()
    {
        return $this->founding_date;
    }

	
}

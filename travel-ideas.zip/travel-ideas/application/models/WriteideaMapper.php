<?php

class Application_Model_WriteideaMapper
{
	 protected $_dbTable;

    public function setDbTable($dbTable)
    {
        if (is_string($dbTable)) {
            $dbTable = new $dbTable();
        }
        if (!$dbTable instanceof Zend_Db_Table_Abstract) {
            throw new Exception('Invalid table data gateway provided');
        }
        $this->_dbTable = $dbTable;
        return $this;
    }
	
	public function getDbTable()
    {
        if (null === $this->_dbTable) {
            $this->setDbTable('Application_Model_DbTable_Writeidea');  //命名
        }
        return $this->_dbTable;
    }
	
	public function save(Application_Model_Writeidea $x)
    {	
		
		
		$temp=$_SESSION["email"];
		
        $data = array(             //数据库录入
        	'travel_ideas' => $x->getTravelIdeas(),
        	'title' => $x->getTitle(), //注意
        	'travel_id' => $x->getTravelId(),
        	'start_date'=> $x->getStartDate(),
        	'end_date'=> $x->getEndDate(),
        	'destination'=> $x->getDestination(),
         	'tags' => $x->getTags(),
        	'title_user'=> $temp,
        	'comment_id'=> $x->getCommentId(),
        	'founding_date'=>date("Y-m-d H:i:s", time()),
        	
        );
        
        $_SESSION['writeidea']="None";
        if (null === ($id = $x->getTravelId())) {
            unset($data['travel_id']);
            try{
            $this->getDbTable()->insert($data);
            }
            catch(Exception $e){
			$_SESSION['writeidea']="Have";
		}
            
        } 
    }
	
	public function update(Application_Model_Writeidea $x)
    {

        $data = array(             //数据库录入
        	'travel_ideas' => $x->getTravelIdeas(),
        	'title' => $x->getTitle(), //注意
        	'start_date'=> $x->getStartDate(),
        	'end_date'=> $x->getEndDate(),
        	'destination'=> $x->getDestination(),
         	'tags' => $x->getTags(),
        	'comment_id'=> $x->getCommentId(),
        	'founding_date'=>date("Y-m-d H:i:s", time()),
        
        );

        if (null === ($title = $x->getTitle())) {
			$this->getDbTable()->update($data, array('title = ?' => $title));
        } else {
            $this->getDbTable()->update($data, array('title = ?' => $title));
        }
    }
	
	public function find($id, Application_Model_Writeidea $x)
    {
        $result = $this->getDbTable()->find($id);
        
		if (0 == count($result)) {
            return;
        }
        $row = $result->current();
        

		
		$id		  ->setTravelId($row->travel_id)
                  ->setTravelIdeas($row->travel_ideas)
				
                  ->setTitle($row->title)
				  ->setStartDate($row->start_date)
                  ->setEndDate($row->end_date)
                  ->setDestination($row->destination)
                  ->setsetTags($row->tags)
                  ->setTitleUser($row->title_user)
                  ->setCommentId($row->comment_id)
                  ->setFoundingDate($row->founding_date);
   
    }
    
    
	
	public function fetchAll()
    {
        $resultSet = $this->getDbTable()->fetchAll();
        $entries   = array();
        foreach ($resultSet as $row) {
            $entry = new Application_Model_Writeidea();
            $entry->setTravelId($row->travel_id)
                  ->setTravelIdeas($row->travel_ideas)
				
                  ->setTitle($row->title)
				  ->setStartDate($row->start_date)
                  ->setEndDate($row->end_date)
                  ->setDestination($row->destination)
                  ->setsetTags($row->tags)
                  ->setTitleUser($row->title_user)
                  ->setCommentId($row->comment_id)
                  ->setFoundingDate($row->founding_date);


            $entries[] = $entry;
        }
        return $entries;
    }

}


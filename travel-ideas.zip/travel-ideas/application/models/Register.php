<?php

class Application_Model_Register
{
    protected $member_id;
    protected $member_name;
	protected $member_password;
	protected $first_name;
	protected $last_name;
	protected $email;


	
	public function __construct(array $options = null)
    {
        if (is_array($options)) {
            $this->setOptions($options);
        }
    }
	
	public function __set($name, $value)
    {
        $method = 'set' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid member property');
        }
        $this->$method($value);
    }

	public function __get($name)
    {
        $method = 'get' . $name;
        if (('mapper' == $name) || !method_exists($this, $method)) {
            throw new Exception('Invalid Member property');
        }
        return $this->$method();
    }
	
	public function setOptions(array $options)
    {
        $methods = get_class_methods($this);
        foreach ($options as $key => $value) {
            $method = 'set' . ucfirst($key);
            if (in_array($method, $methods)) {
                $this->$method($value);
            }
        }
        return $this;
    }
	
	public function setMemberId($memberId)
    {
        $this->member_id = (int) $memberId;
        return $this;
    }

    public function getMemberId()
    {
        return $this->member_id;
    }
	
	public function setMemberName($memberName)
    {
        $this->member_name = (string) $memberName;
        return $this;
    }

    public function getMemberName()
    {
        return $this->member_name;
    }
	
	public function setMemberPassword($memberPassword)
    {
        $this->member_password = (string) $memberPassword;
        return $this;
    }

    public function getMemberPassword()
    {
        return $this->member_password;
    }

	
	public function setFirstName($firstName)
    {
        $this->first_name = (String) $firstName;
        return $this;
    }

    public function getFirstName()
    {
        return $this->first_name;
    }
	
	public function setLastName($lastName)
    {
        $this->last_name = (String) $lastName;
        return $this;
    }

    public function getLastName()
    {
        return $this->last_name;
    }
	
	public function setEmail($email)
    {
        $this->email = (String) $email;
        return $this;
    }

    public function getEmail()
    {
        return $this->email;
    }

	
}


<?php

class Application_Form_Writeidea extends Zend_Form
{

	

	public function __construct($options = null) 
    { 
        parent::__construct($options);
     
		/*
        $description = new Zend_Form_Element_Textarea('TravelIdeas');
        $description->addFilter('StringToLower')
        			->setLabel('TravelIdeas')
                	->setRequired(true)
   	 				->setAttrib('COLS', '40')
    				->setAttrib('ROWS', '4');
        
        $this->addElements($description);	
*/
	} 



    public function init()
    {
    	

        /* Form Elements & Other Definitions Here ... */
		        // Set the method for the display form to POST
        $this->setMethod('post');

        // Add an name element
      
       	
        
        
        $this->addElement('text', 'Title', array(
            'label'      => 'Title:',
            'required'   => true,      
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(5, 100))
                )     
        ));
		
		$this->addElement('text', 'Destination', array(
            'label'      => 'Destination',
            'required'   => true,      
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(5, 100))
				
                )     
        ));
		
		$this->addElement('text', 'StartDate', array(
            'label'      => 'Start_date:',
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(3, 50))
				
                )     
        ));
        $this->addElement('text', 'EndDate', array(
            'label'      => 'End_date:',
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(3, 50))
				
                )     
        ));
        
        
        
        $this->addElement('textarea', 'TravelIdeas', array(
            'label'      => 'Travel_ideas:',
			'validators' => array(
                array('validator' => 'StringLength','ROWS'=>'4','COLS'=>'40','options' => array(2, 1000))
				
                )     
        ));
        
        
        $this->addElement('text', 'Tags', array(
            'label'      => 'Tags(city):',
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(2, 100))
				
                )     
        ));
        
        
        
		
		$this->addElement('submit', 'submit', array(
            'ignore'   => true,
            'label'    => 'Submit',
        ));
		
		$this->addElement('reset', 'reset', array(
            'ignore'   => true,
            'label'    => 'Cancel',
        ));
		
    }


}


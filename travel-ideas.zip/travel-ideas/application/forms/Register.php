<?php

class Application_Form_Register extends Zend_Form
{

	public function __construct($options = null) 
    { 
        parent::__construct($options);
     

       $email = new Zend_Form_Element_Text('Email');
        $email->setLabel('Email address')
              ->addFilter('StringToLower')
              ->setRequired(true)
              ->addValidator('NotEmpty', true)
              ->addValidator('EmailAddress');  
		$this->addElements(array($email));	  		
		
		$confirmed_password = new Zend_Form_Element_Password('confirmedPassword');
        $confirmed_password->addValidator('Idenical',false,array('token' => 'memberPassword'))
                           ->setLabel('confirmed password')
                           ->addErrorMessage('The passwords do not match')
						   ->setRequired(true)
						   ->addValidator('NotEmpty', true)
						   ->addValidator('password');

	} 



    public function init()
    {

        /* Form Elements & Other Definitions Here ... */
		        // Set the method for the display form to POST
        $this->setMethod('post');

        // Add an name element
        $this->addElement('text', 'MemberName', array(
            'label'      => 'Member_name:',
            'required'   => true,      
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(5, 20))
                )     
        ));
		
		$this->addElement('password', 'MemberPassword', array(
            'label'      => 'Password:',
            'required'   => true,      
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(5, 20))
				
                )     
        ));
		
		$this->addElement('password', 'confirmedPassword', array(
            'label'      => 'Confirmed password:',
			'required'	 => true,
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(5, 20))
				
                )     
        ));
		
		$this->addElement('text', 'FirstName', array(
            'label'      => 'First name:',
            'required'   => true,      
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(3, 50))
                )     
        ));
		
		$this->addElement('text', 'LastName', array(
            'label'      => 'Last name:',     
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(3, 50))
                )     
        ));
		
		$this->addElement('text', 'Email', array(
            'label'      => 'e_mail:',
			'required'	 => true,
			'validators' => array(
                array('validator' => 'StringLength', 'options' => array(3, 50)),
                )     
        ));
	
		$this->addElement('submit', 'submit', array(
            'ignore'   => true,
            'label'    => 'Register',
        ));
		
    }


}


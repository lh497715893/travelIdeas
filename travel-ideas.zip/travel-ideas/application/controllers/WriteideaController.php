<?php

class WriteideaController extends Zend_Controller_Action
{

    public function init(){
	
		$this->db = Zend_Registry::get('db');
	}
	

    public function indexAction()
    {
        $this->_redirect('/writeidea/writeidea');
    }

	public function failAction(){
		
	}
    public function writeideaAction()
    {
        $request = $this->getRequest();
        $form    = new Application_Form_Writeidea();
		session_start();
		if ($this->getRequest()->isPost()) {
            if ($form->isValid($request->getPost())) {
                $writeidea = new Application_Model_Writeidea($form->getValues());//bug
                $mapper  = new Application_Model_WriteideaMapper();
				
					$title=$_POST['Title'];
					
					
					$_SESSION['title']=$title;
					
				$mapper->save($writeidea);
				$result=$_SESSION['writeidea'];
			if($result == "None"){
				return $this->_redirect('/main/after');
			}else if($result == "Have"){
					 $this->_redirect('/writeidea/fail');
			}
				
            }
            /*
            $temp=$_SESSION["email"];
    	
            $sql1 = "SELECT * FROM `members` WHERE email='$temp'";
            $result1=$this->db->fetchAssoc($sql1);
    		$this->view->assign('datas',$result1);
    		$datas = $this->datas;
			foreach($datas as $member){
			$_SESSION["member_id"]= $member['member_id'];
			} 
			
			$temp1=$_SESSION["member_id"];
			$datatest = array(
				'title_user'   => '$temp1',
			);
			$this->getDbTable()->insert($datatest);*/
            
        }
		
        $this->view->form = $form; 
        
    }
	
	public function editAction()
	{
	    $request = $this->getRequest();
        $form    = new Application_Form_Edit();
		session_start();
		if ($this->getRequest()->isPost()) {
            if ($form->isValid($request->getPost())) {
                $writeidea = new Application_Model_Writeidea($form->getValues());//bug
                $mapper  = new Application_Model_WriteideaMapper();
				
					$title=$_POST['Title'];
					
					
					$_SESSION['title']=$title;
					
				$mapper->update($writeidea);
				return $this->_redirect('/writeidea/editsuccessful');
				$result=$_SESSION['writeidea'];
				
            }
            /*
            $temp=$_SESSION["email"];
    	
            $sql1 = "SELECT * FROM `members` WHERE email='$temp'";
            $result1=$this->db->fetchAssoc($sql1);
    		$this->view->assign('datas',$result1);
    		$datas = $this->datas;
			foreach($datas as $member){
			$_SESSION["member_id"]= $member['member_id'];
			} 
			
			$temp1=$_SESSION["member_id"];
			$datatest = array(
				'title_user'   => '$temp1',
			);
			$this->getDbTable()->insert($datatest);*/
            
        }
		
        $this->view->form = $form; 	
	
	}
	
	public function editsuccessfulAction(){
				
	}
	
	

}




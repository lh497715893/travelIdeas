<?php 


class SigninController extends Zend_Controller_Action
{

	
	
    public function indexAction()
    {
		/* default to the view action */
		$this->_redirect('/Sign/view');
		//$this->_helper->redirector('view');		
	}
	
	/*	public function viewAction()
    {
        $book = new Application_Model_BookMapper();
        $this->view->auth = $book->fetchAll();
    }*/
	public function viewAction()
    {
        $db = $this->_getParam('db');
 
        $loginForm = new Application_Form_Login();
 		
        if ($loginForm->isValid($_POST)) {
 
            $adapter = new Zend_Auth_Adapter_DbTable(
                $db,
                'members',
                'email',
                'member_password'

                );
			
            $adapter->setIdentity($loginForm->getValue('username'));
            $adapter->setCredential($loginForm->getValue('password'));
            
           
        
            $auth   = Zend_Auth::getInstance();
            
            
            
            $result = $auth->authenticate($adapter);
            session_start();
            $_SESSION["email"]=$loginForm->getValue('username');
            $_SESSION["password"]=$loginForm->getValue('username');
           // $temp=$_SESSION["email"];
            //$sql = "SELECT * FROM `members`";
            //$this->db->fetchAssoc($sql);
            //	$result1 = $this->db->fetchAssoc($sql);
            //$this->view->assign('datas',$result1); 

  			
            
            
            
            
            
            
            
            if ($result->isValid()) {
                $this->_helper->FlashMessenger('Successful Login');
				
                $this->_redirect('/main/after');
                
                return;
            }else{
				$this->_helper->FlashMessenger('Successful failed');

                $this->_redirect('../Signin/view');
                return;
			}
 			
        }
 	    //session_start();
 	    //session_start();	
        //$_SESSION["email"]=$loginForm->getValue('username');
         
            //$_SESSION["test1"]="test2";
            
        //$first_name = "SELECT * FROM `members`" ;
       // $result1 = mysql_query($first_name);
            
            
        //$_SESSION["firstname"]=$result1;
 	    
 	    
 	    
 	    
        $this->view->form = $loginForm;

		$_SESSION["log"]="Log in";

 
    }
	
	public function editAction()
	
    {
        $request = $this->getRequest();
        $form    = new Application_Form_Edit();
		
		if ($this->getRequest()->isPost()) {
            if ($form->isValid($request->getPost())) {
                $member = new Application_Model_Member($form->getValues());
                $mapper  = new Application_Model_MemberMapper();
                $mapper->update($member);
                return $this->_redirect('auth/view');
            }
        }

        $this->view->form = $form;
		
	}
	
	public function logoutAction()
	
    {
		$this->_redirect('/Signin/view');
		
	}
	

}



/*class SigninController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    /*}

    public function indexAction()
    {
        $this->_redirect('/main/after');
    }
    
    
/


    public function viewAction()
    {
       //$request = $this->getRequest();
        $form    = new Application_Form_Register();
		
		

        $this->view->form = $form;
    }


}*/


?>

<?php

class IndexController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        //session_start();
		//$_SESSION["log"]="Log in";
		
		$this->_redirect('/main/view');
    }

    public function writeideaAction()
    {
        // action body
    }

    public function itemAction()
    {
        // action body
    }


}






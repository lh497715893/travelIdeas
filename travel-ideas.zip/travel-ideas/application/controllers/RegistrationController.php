<?php

class RegistrationController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
			
    }

    public function indexAction()
    {
        // action body
		$this->_redirect('/registration/register');
    }
	
	public function loginAction()
	{
	//	$this->_redirect('/registration/login');
	}
	
	public function registerAction()
	{
		$request = $this->getRequest();
        $form    = new Application_Form_Register();
		
		if ($this->getRequest()->isPost()) {
            if ($form->isValid($request->getPost())) {
                $registration = new Application_Model_Register($form->getValues());
                $mapper  = new Application_Model_RegisterMapper();
				
					$memberName=$_POST['MemberName'];
					session_start();
					$_SESSION['memberName']=$memberName;
				//	$_SESSION['memberName']="aaaaaa";
				$mapper->save($registration);
				$result=$_SESSION['register'];
			if($result == "None"){
				return $this->_redirect('/registration/successful');
			}else if($result == "Have"){
				return $this->_redirect('/registration/fail');
			}
				
               //return $this->_helper->redirector('/successful');
            }
        }

        $this->view->form = $form;
	}
	
	public function successfulAction()
	{
	//	$this->_redirect('/registration/successful');
	}
	
	public function failAction()
	{
		
	}

}


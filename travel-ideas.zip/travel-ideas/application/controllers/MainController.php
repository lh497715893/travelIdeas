<?php
session_start();
class MainController extends Zend_Controller_Action
{
	
	public function init(){
	
		$this->db = Zend_Registry::get('db');
	}
	

    public function indexAction()
    {
        // action body
        //session_start();
		//$_SESSION["log"]="Log in";
		$this->_redirect('/main/view');
		
    }
	    public function viewAction()
    {
        // action body

    }
		public function afterAction()
    {	
		$ideas = new Application_Model_WriteideaMapper();
		$request = $this->getRequest();
		$search = $request->getParam("search");	
		$filteredSearch = ($search) ? strip_tags(htmlspecialchars($search, ENT_QUOTES)) : 'jquery';
		session_start();
		$_SESSION["log"]="Log out";
		$_SESSION["writeidea"]="Create your ideas";
        // action body
    	$temp=$_SESSION["email"];
		
		
	//	$this->view->after = $ideas->fetchAll();
				
	//	$filteredSearch="Shanghai";
			// Local book search
		$sql = "SELECT * FROM `travel_ideas` where title like '%$filteredSearch%'";
	if($filteredSearch!=$search){
		$sql = "SELECT * FROM `travel_ideas`";
	}
		$result = $this->db->fetchAssoc($sql);
		$this->view->assign('search',$search);
		$this->view->assign('ideas',$result); 
    	
        $sql1 = "SELECT * FROM `members` WHERE email='$temp'";
        //$sql1 = "SELECT * FROM `members`";
    	$result1 = $this->db->fetchAssoc($sql1);
        $register = new Application_Model_RegisterMapper();
        $this->view->registers = $register->fetchAll();
    	$this->view->assign('datas',$result1); 
    	//$_SESSION["test"]=
       
		
		
		
    }

	public function detailAction()
	{
		$request = $this->getRequest();
		$search = $request->getParam("search");
		$city = $request->getParam("city");	
		$day = $request->getParam("day");	
	//	$day = $request->getParam("day");	
	//	$filteredSearch = ($search) ? strip_tags(htmlspecialchars($search, ENT_QUOTES)) : 'jquery';
		
		$this->view->assign('search',$search);
		$this->view->assign('city',$city);
		$this->view->assign('day',$day);
	}
	
	public function itemAction(){
		$request = $this->getRequest();
		$id = $request->getParam("id");
		
		$sql = "SELECT * FROM `travel_ideas` WHERE travel_id='".$id."'";
		$result = $this->db->fetchRow($sql);
		
		$this->view->assign('data',$result);
		$this->view->assign('action', $request->getBaseURL()."/main/item");
	    $_SESSION["edit_title"]=$this->data['title'];
	    $_SESSION["edit_destination"]=$this->data['destination'];
	    $_SESSION["edit_details"]=$this->data['travel_ideas'];
	    $_SESSION["edit_tags"]=$this->data['tags'];
	

	}

}


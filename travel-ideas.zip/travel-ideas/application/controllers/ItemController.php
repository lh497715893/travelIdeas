<?php

class ItemController extends Zend_Controller_Action
{

    public function init(){
	
		$this->db = Zend_Registry::get('db');
	}
	

    public function indexAction()
    {
        $this->_redirect('/item/item');
    }
	
	 public function itemAction()
    {
        $sql = "SELECT * FROM `travel_ideas` WHERE travel_id=7";
    	$result1=$this->db->fetchAssoc($sql);
        	
    	$this->view->assign('travelshow',$result1); 
    	//$_SESSION["test"]=
        
       
    }
	
	/* Insert a new book */
    public function insertAction()
    {
        $request = $this->getRequest();
        $form    = new Application_Form_Book();
		
		if ($this->getRequest()->isPost()) {
            if ($form->isValid($request->getPost())) {
                $book = new Application_Model_Book($form->getValues());
                $mapper  = new Application_Model_BookMapper();
                $mapper->save($book);
                return $this->_helper->redirector('view');
            }
        }

        $this->view->form = $form;
    }


}


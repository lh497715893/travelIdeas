<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
protected function _initDoctype()
    {
        $this->bootstrap('view');
        $view = $this->getResource('view');
        $view->doctype('XHTML1_STRICT');
	
    }
			protected function _initDB()
			{
			       $parameters  = array(
			               'host' => 'localhost',
			               'username' => 'root',
			               'password' =>'',
			               'dbname' =>'travel_ideas'
			       );
			       try {
			               $db = Zend_Db::factory('Pdo_Mysql', $parameters );
			               $db->getConnection();
			       } catch (Zend_Db_Adapter_Exception $e) {
			               echo $e->getMessage();
			               die('Could not connect to database.');
			       } catch (Zend_Exception $e) {
			               echo $e->getMessage();
			               die('Could not connect to database.');
			       }
			       Zend_Registry::set('db', $db);
			       Zend_Db_Table_Abstract::setDefaultAdapter($db);
			} 

    protected function _initAutoload()
    {
        $moduleLoader = new Zend_Application_Module_Autoloader(array(
            'namespace' => '', 
            'basePath'  => APPLICATION_PATH));
        return $moduleLoader;
        
    }
   
    /**
     * Setup the view
     */
     /*
    protected function _initViewSettings()
    {
        
        $this->bootstrap('view');

        $this->_view = $this->getResource('view');

        // add global helpers
        $this->_view->addHelperPath(APPLICATION_PATH . '/views/helpers', 'Zend_View_Helper');

        // set encoding and doctype
        $this->_view->setEncoding('UTF-8');
        $this->_view->doctype('XHTML1_STRICT');

        // set the content type and language
        $this->_view->headMeta()->appendHttpEquiv('Content-Type', 'text/html; charset=UTF-8');
        $this->_view->headMeta()->appendHttpEquiv('Content-Language', 'en-US');

        // set css links and a special import for the accessibility styles
        //$this->_view->headStyle()->setStyle('@import "/css/access.css";');
        $this->_view->headLink()->appendStylesheet('/css/style.css');
        $this->_view->headLink()->appendStylesheet('/css/main.css');
        $this->_view->headLink()->appendStylesheet('/css/product_info.css');

        // setting the site in the title
        $this->_view->headTitle('ZF Online Bookstore');

        // setting a separator string for segments:
        $this->_view->headTitle()->setSeparator(' - ');
    }
*/
}
?>